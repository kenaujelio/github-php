#### Getting Started

Clone Repository

`git clone https://github.com/hattorihanzo86/LaravelAntiFakeNews`

**Install Requirements**

`composer install`

**Create a database in your MYSQL**

`antifakenewsdb`

**Running Migration**

Important : Make sure .env is properly configured.
Run this command in the terminal

`php artisan migrate --seed`

** Createting app key **

`php artisan key:generate`


**Running Server**

`php artisan serve`

**Default credentials**

`Username: admin@admin.com`

`Password: password`