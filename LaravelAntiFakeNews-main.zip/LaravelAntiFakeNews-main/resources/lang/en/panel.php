<?php

return [
    'site_title' => 'AntiFakeNews',

];
