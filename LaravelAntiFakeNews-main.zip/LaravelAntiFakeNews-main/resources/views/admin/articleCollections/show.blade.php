@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.articleCollection.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.article-collections.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.articleCollection.fields.id') }}
                        </th>
                        <td>
                            {{ $articleCollection->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.articleCollection.fields.category') }}
                        </th>
                        <td>
                            {{ $articleCollection->category->name ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.articleCollection.fields.title') }}
                        </th>
                        <td>
                            {{ $articleCollection->title }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.articleCollection.fields.details') }}
                        </th>
                        <td>
                            {!! $articleCollection->details !!}
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.article-collections.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
        </div>
    </div>
</div>



@endsection