@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.create') }} {{ trans('cruds.offensiveWord.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.offensive-words.store") }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label class="required" for="word">{{ trans('cruds.offensiveWord.fields.word') }}</label>
                <input class="form-control {{ $errors->has('word') ? 'is-invalid' : '' }}" type="text" name="word" id="word" value="{{ old('word', '') }}" required>
                @if($errors->has('word'))
                    <div class="invalid-feedback">
                        {{ $errors->first('word') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.offensiveWord.fields.word_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection