@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.reliableSource.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.reliable-sources.update", [$reliableSource->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="name">{{ trans('cruds.reliableSource.fields.name') }}</label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', $reliableSource->name) }}" required>
                @if($errors->has('name'))
                    <div class="invalid-feedback">
                        {{ $errors->first('name') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.reliableSource.fields.name_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="source_url">{{ trans('cruds.reliableSource.fields.source_url') }}</label>
                <input class="form-control {{ $errors->has('source_url') ? 'is-invalid' : '' }}" type="text" name="source_url" id="source_url" value="{{ old('source_url', $reliableSource->source_url) }}" required>
                @if($errors->has('source_url'))
                    <div class="invalid-feedback">
                        {{ $errors->first('source_url') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.reliableSource.fields.source_url_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection